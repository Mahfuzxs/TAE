package com.example.mahfuz.week2day2morning;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Save extends AppCompatActivity {

    private TextView tvSave;
    private EditText etSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save);

        etSave = findViewById(R.id.etSave);
    }

    @Override
    protected void onResume() {
        super.onResume();


    }

    public void onSave(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("sp", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("Save", etSave.getText().toString());
        editor.commit();

        Intent intent = new Intent(this, MainActivity.class);
        //intent.putExtra("savedValue", tvSave.getText().toString() + " saved Successful");
        startActivity(intent);
    }
}