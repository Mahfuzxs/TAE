package com.example.mahfuz.week2day2morning;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView tvDisplay;
    private Button btnSave, btnQuery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvDisplay = findViewById(R.id.tvDisplay);
        btnQuery = findViewById(R.id.btnQuery);
        btnSave = findViewById(R.id.btnSave);


    }

    public void onSave(View view) {
        Intent intent = new Intent(this, Save.class);
        startActivity(intent);
        finish();

    }

    public void onQuery(View view) {
    }

    @Override
    protected void onResume() {
        SharedPreferences sharedPreferences = getSharedPreferences("sp", Context.MODE_PRIVATE);
        String save = sharedPreferences.getString("Save","");
        tvDisplay.setText(save);

        super.onResume();
    }
}
